# Multistore Online
#### Video Demo:  https://youtu.be/rydjCDUL5Gw
#### Description:

For the final project of cs50 I have built an e-commerce website for a friend's online business. The website is called 'Multistore Online' where one can buy different gadgets like watches and earphones.

For this project I have used html, css, bootstrap, python and flask. I have also used sqlite3 to store datasets in sql table. The required modules are imported including sqlite3. Then connect method is used and databse name is passed to it. Then cursor method is used to create a cursor object which enabels to pass the sql statements. 

On the homepage you can already see some products which are mostly watches. These products are shown from a sql table called 'product_data' which I have created and entered at the start. The table consists of the details of each product and name of the image file it is supposed to display. The images are stored in static folder and are already present. Each of the product in homepage has two options where one can opt to either buy the product now or to add to the cart. 

Another table cart_product is also created to store the products added to cart. 

When the 'Buy' button is pressed, the user are redirected to buy page using flask with the information of which product was selected. In this buy page the price of the product is shown and user are requested to select the mode of payment.  The purchase can be made after clicking on the buy button in this page.

One can also add different products on the cart and buy them at once. The cart page can be assessed after clicking on cart icon in navbar. On the cart page there is also an option to remove any product from cart. The buy button from this page redirects to the buy page but with the total value from the cart. 

There is also a search bax in the fixed navbar from which one can search for product by typing in the product name. Searching on the box sends the post request to the index function. The searched product name is accessed from the request.form.get command and the search_products variable stores the data of the product with same name. 

In order to add or remove products one need to login as an admin and get access to admin page. The admin login page is at the top of the page at around middle-right. After entering username and password which are 'Online23' and 'online23' respectively, the admin page is loaded. If the passwords donot match a message is provided saying to enter the correct username or password. To add a product every product details need to be given like product name, prices and the photo to display need to be uploaded. The image is uploaded to the static folder if an image of same name doesnot exist. THe name of the image will be the product symbol with .jpg format. The home page is loaded if adding item was successful where one can see the added product. Also similar process is to be followed to delete a product except after clicking on the delete product only the product symbol need to be provided and the product is deleted. 

One can access to home page from every page by clicking on home button at the top of each page. Clicking on the name 'Multistore Online' will also redirect to the homepage. 

The files I have created are templates file which contains all the templates file for each of the page. The static file contains styles.css which has the css for all of the project. The static file also contains the image of the products which loads the first time. 