
from flask import Flask, render_template, request, redirect
from datetime import datetime
import os
import sqlite3


connection = sqlite3.connect("products.db",check_same_thread=False)

product_data = [
    ("Watch", "Zenith Watch", "Wa001", "Watch for men. One year warranty", "3500", "2900", datetime.now(), "./static\\Wa001.jpg"), 
    ("Watch", "Bell & Ross Watch", "Wa002", "Stylish Watch. One year warranty", "3600", "3100", datetime.now(), "./static\\Wa002.jpg"),
    ("Watch", "Bamford Watch", "Wa003", "Smart Watch. Formal Party wear.", "3400", "2800", datetime.now(), "./static\\Wa003.jpg"),
    ("Watch", "Tudor Watch", "Wa004", "Watch for men. 2 years warranty", "3800", "3000", datetime.now(), "./static\\Wa004.jpg"),
    ("Watch", "Alpina Watch", "Wa005", "Watch for men. 2 years warranty", "3300", "2700", datetime.now(), "./static\\Wa005.jpg"),
    ("Watch", "Rolex", "Wa006", "Watch .Colourful. 2 years warranty", "3000", "2500", datetime.now(), "./static\\Wa006.jpg"),
]
cursor = connection.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS products (product_category VARCHAR(12), product_name VARCHAR(15), product_symbol VARCHAR(8), product_description VARCHAR(20), market_price INT NOT NULL, offered_price INT NOT NULL, date datetime, photo_name VARCHAR[50])")
cursor.execute("CREATE TABLE IF NOT EXISTS cart_products (product_category VARCHAR(12), product_name VARCHAR(15), product_symbol VARCHAR(8), product_description VARCHAR(20), market_price INT NOT NULL, offered_price INT NOT NULL, date datetime, photo_name VARCHAR[50])")
for i in range(6):
    cursor.execute("INSERT into products (product_category, product_name, product_symbol, product_description, market_price, offered_price, date, photo_name) VALUES (?,?,?,?,?,?,?,?)", (product_data[i][0], product_data[i][1], product_data[i][2], product_data[i][3], product_data[i][4], product_data[i][5], product_data[i][6], product_data[i][7]))

app = Flask(__name__)

app.config["SECRET_KEY"] = "secret"

admin = []

UPLOAD_FOLDER = './static'

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route("/", methods = ["GET", "POST"])
def index():
    if request.method == "GET":

    # Select all the transactions made by logged in user.
        all_products = cursor.execute("SELECT * FROM products").fetchall()
        length = len(all_products)
        print ("length",length)
        print("allproducts:", all_products)

        if length < 1:
            return render_template("index.html",l = 0)  
        else:
            for i in range(length):
                name ="C:\\Users\\adhkr\\.vscode\\hello_flask\\static\\" + all_products[i][2] + ".jpg"
                return render_template("index.html", allp = all_products,l = int(length), name = name)    
   
    else:
        search = request.form.get("search")
        search_products = cursor.execute("SELECT * FROM products WHERE product_name LIKE ?", (search,)).fetchall()
        search_length = len(search_products)
        print ("slength",search_length)
        print("search:", search)
        print("sallproducts:", search_products)
        if search:
            if search_length < 1:
                return render_template("index.html",l = 0)  
            else:
                for i in range(search_length):
                    name ="C:\\Users\\adhkr\\.vscode\\hello_flask\\static\\" + search_products[i][2] + ".jpg"
                    return render_template("index.html", allp = search_products,l = int(search_length), name = name)

@app.route("/admin_login", methods = ["GET", "POST"])
def admin_login():

    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if not username:
            return ("must provide username", 403)

        # Ensure password was submitted
        elif not password:
            return ("must provide password", 403)

        # Ensure username exists and password is correct
        if username != "Online23" or password !=  "online23":
            return ("invalid username and/or password", 403)

        else:   
        # Redirect user to home page
            admin.append("admin")
            print("%s", admin)
            return redirect("/admin_page")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("admin_login.html")


@app.route("/admin_page")
def admin_page():

    if len(admin) > 0:
        return render_template("admin_page.html")
        
    else:
        return render_template("admin_login.html")


# ADD Products
@app.route("/add_products", methods = ["GET", "POST"])
def add_products():

    if request.method == "POST":
        category = request.form.get("category")
        name = request.form.get("name")
        symbol = request.form.get("symbol")
        description = request.form.get("description")
        mprice = request.form.get("market_price")
        oprice = request.form.get("offered_price")
        date = datetime.now()
        pic = request.files.get("pics")
        pic.filename = symbol + ".jpg"
        filename = os.path.join(app.config['UPLOAD_FOLDER'], pic.filename)
        pic.save(filename)
        
        if not cursor.execute("INSERT into products (product_category, product_name, product_symbol, product_description, market_price, offered_price, date, photo_name) VALUES (?,?,?,?,?,?,?,?)",
                (category, name, symbol, description, mprice, oprice, date, filename)):
            print("Enter Correct info")

        return redirect("/")
    else:
        return render_template("add_products.html")


@app.route("/delete_products", methods = ["GET", "POST"])
def delete_products():

    if request.method == "POST":
        symbol = request.form.get("symbol")

        if not cursor.execute("DELETE FROM products where product_symbol = ?", (symbol,)):
            print("Enter Correct Symbol")
        return redirect("/")
    else:
        return render_template("delete_products.html")
admin.clear()


@app.route("/cart", methods = ["GET", "POST"])
def cart():
    if request.method == "POST":
        id = request.form.get("id")
        cursor.execute("INSERT into cart_products SELECT * from products where product_symbol = ?",(id,)).fetchall()
        return redirect("/")
    else:
        cart_products = cursor.execute("SELECT* FROM cart_products").fetchall()
        length = len(cart_products)
        sum_cart = cursor.execute("SELECT SUM(offered_price) FROM cart_products").fetchall()
        return render_template("cart.html", allp = cart_products, l = length, sum = sum_cart[0][0])


@app.route("/buy", methods = ["POST"])
def buy():
    if request.method == "POST":
        id = request.form.get("id")
        print("idcosr: ",id)
        cost = cursor.execute("SELECT offered_price FROM products WHERE product_symbol = ?",(id,) ).fetchall()
        print("cosr: ",cost)
        return render_template("buy.html", cost = cost[0][0])


@app.route("/buy_cart", methods = ["GET", "POST"])
def buy_cart():
    if request.method == "POST":
        sum = request.form.get("cart_sum")
        print("sum", sum)
        return render_template("buy.html", cost = sum)


@app.route("/remove", methods = ["POST"])
def remove():
    if request.method == "POST":
        id = request.form.get("remove")
        cursor.execute("DELETE FROM cart_products WHERE product_symbol = ?;",(id,))
        #cursor.execute("DELETE FROM cart_products WHERE product_name IN (SELECT product_name FROM cart_products WHERE product_symbol = ? LIMIT 1)")
        cart_products = cursor.execute("SELECT * FROM cart_products").fetchall()
        length = len(cart_products)
        sum_cart = cursor.execute("SELECT SUM(offered_price) FROM cart_products").fetchall()
        print("clength", length)
        return render_template("cart.html", allp = cart_products, l = length, sum = sum_cart[0][0])


if __name__ == "__main__":
    app.run(host='127.0.0.1', port=8080, debug=True)
